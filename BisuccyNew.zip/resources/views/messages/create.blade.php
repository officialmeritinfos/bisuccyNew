<x-app-layout>
  <x-slot name="pageTitle">
      {{ __('createMessage') }}
  </x-slot>
</x-app-layout>