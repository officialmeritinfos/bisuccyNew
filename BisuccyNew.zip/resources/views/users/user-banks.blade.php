<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('userBanks') }}
    </x-slot>
</x-app-layout>