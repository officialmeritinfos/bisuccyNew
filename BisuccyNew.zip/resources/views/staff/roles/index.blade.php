<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('roles') }}
    </x-slot>
</x-app-layout>