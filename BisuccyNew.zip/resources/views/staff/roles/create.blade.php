<x-app-layout>
  <x-slot name="pageTitle">
      {{ __('createRole') }}
  </x-slot>
</x-app-layout>