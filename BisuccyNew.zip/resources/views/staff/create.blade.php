<x-app-layout>
  <x-slot name="pageTitle">
      {{ __('createStaff') }}
  </x-slot>
</x-app-layout>