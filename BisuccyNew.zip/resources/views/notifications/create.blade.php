<x-app-layout>
  <x-slot name="pageTitle">
      {{ __('createNotification') }}
  </x-slot>
</x-app-layout>