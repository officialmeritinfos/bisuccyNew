import en from '../../../lang/en.json'

export const defaultLocale = 'en'

export const languages = {
  en: en
}