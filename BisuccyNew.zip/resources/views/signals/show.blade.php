<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('signalDetails') }}
    </x-slot>
</x-app-layout>