<x-app-layout>
  <x-slot name="pageTitle">
      {{ __('createSystemFiatAccount') }}
  </x-slot>
</x-app-layout>