<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('userPurchases') }}
    </x-slot>
</x-app-layout>