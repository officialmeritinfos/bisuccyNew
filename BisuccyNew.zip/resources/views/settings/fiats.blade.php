<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('fiatlist') }}
    </x-slot>
</x-app-layout>