<x-app-layout>
  <x-slot name="pageTitle">
      {{ __('createSignal') }}
  </x-slot>
</x-app-layout>