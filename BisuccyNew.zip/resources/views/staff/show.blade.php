<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('staffDetails') }}
    </x-slot>
</x-app-layout>