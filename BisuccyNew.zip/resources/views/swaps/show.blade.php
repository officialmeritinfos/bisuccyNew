<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('swapDetails') }}
    </x-slot>
</x-app-layout>