<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('settings') }}
    </x-slot>
</x-app-layout>