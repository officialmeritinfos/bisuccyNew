<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('createFiat') }}
    </x-slot>
</x-app-layout>