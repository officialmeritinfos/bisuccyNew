<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('systemAccounts') }}
    </x-slot>
</x-app-layout>