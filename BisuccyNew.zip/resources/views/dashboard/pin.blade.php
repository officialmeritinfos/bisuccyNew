<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('set pin') }}
    </x-slot>
</x-app-layout>