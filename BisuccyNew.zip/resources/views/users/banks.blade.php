<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('usersBanks') }}
    </x-slot>
</x-app-layout>