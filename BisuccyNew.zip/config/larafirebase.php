<?php

return [

    'authentication_key' => "AAAAuiyFq68:APA91bFenoxb5Ue0vnZF5-zb8BxhISQfya778ssG2J94FilhM3refjXoqeKseDGxOYIOwczpn2-dutzaLAFmQUXLwQ2IdSNuUQu04r78MQ4b-naUDGw2xpHmCFhVkm1kcvF5BsC6pSik"

];
