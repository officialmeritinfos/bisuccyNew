<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title> <?php echo e(isset($pageTitle) ? $pageTitle : "Page"); ?> - <?php echo e(config('app.name', 'Bisuccy')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</head>

<body class="antialiased bg-gray-50">
    <main>
        <section class="relative flex flex-col items-center w-full h-full min-h-screen">
            <div class="container m-auto px-4 h-full">
                <?php echo e($slot); ?>

            </div>
        </section>
    </main>
    <script>
        window.appModule = {
            currentLocale: '<?php echo e(App::currentLocale()); ?>',
            adminPrefix: '<?php echo e(config('app.admin-route-prefix')); ?>',
        };
    </script>
</body>

</html><?php /**PATH C:\Kopium apps\clientsWork\BisuccyNew\resources\views/layouts/guest.blade.php ENDPATH**/ ?>