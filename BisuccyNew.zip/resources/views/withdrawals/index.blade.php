<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('withdrawals') }}
    </x-slot>
</x-app-layout>