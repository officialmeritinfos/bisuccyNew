<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('userFiatWithdrawals') }}
    </x-slot>
</x-app-layout>