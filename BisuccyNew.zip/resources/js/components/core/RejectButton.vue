<template>
    <button class="btn btn-danger w-32 mr-2 mb-2">
        <SlashIcon class="w-4 h-4 mr-2" /> {{$t('reject')}}
    </button>
</template>
<script setup>
</script>
