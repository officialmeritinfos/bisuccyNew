<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('systemAccountDetails') }}
    </x-slot>
</x-app-layout>