<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('systemFiatAccounts') }}
    </x-slot>
</x-app-layout>