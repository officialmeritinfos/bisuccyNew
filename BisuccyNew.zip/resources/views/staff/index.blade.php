<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('staffList') }}
    </x-slot>
</x-app-layout>