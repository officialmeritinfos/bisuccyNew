<?php

namespace App\Http\Controllers\Mobile\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class VerifySession extends Controller
{
    public function authenticate(Request $request)
    {

    }
}
