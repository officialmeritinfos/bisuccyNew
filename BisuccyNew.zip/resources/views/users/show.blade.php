<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('userDetails') }}
    </x-slot>
</x-app-layout>