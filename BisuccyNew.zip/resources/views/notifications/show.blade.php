<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('notificationDetails') }}
    </x-slot>
</x-app-layout>