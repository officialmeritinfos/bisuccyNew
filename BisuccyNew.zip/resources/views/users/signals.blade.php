<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('userSignals') }}
    </x-slot>
</x-app-layout>