<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('messageDetails') }}
    </x-slot>
</x-app-layout>