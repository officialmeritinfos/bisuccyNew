<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('dashboard') }}
    </x-slot>
</x-app-layout>