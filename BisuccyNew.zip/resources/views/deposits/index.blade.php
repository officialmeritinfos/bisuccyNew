<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('deposits') }}
    </x-slot>
</x-app-layout>