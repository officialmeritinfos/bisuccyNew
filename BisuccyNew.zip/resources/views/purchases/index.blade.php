<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('purchases') }}
    </x-slot>
</x-app-layout>