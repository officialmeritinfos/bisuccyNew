<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('signals') }}
    </x-slot>
</x-app-layout>