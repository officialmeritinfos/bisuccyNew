<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('userProfile') }}
    </x-slot>
</x-app-layout>