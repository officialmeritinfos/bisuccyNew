<x-app-layout>
    <x-slot name="pageTitle">
        {{ __('notifications') }}
    </x-slot>
</x-app-layout>